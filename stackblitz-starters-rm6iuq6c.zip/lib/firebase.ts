// lib/firebase.ts
import { initializeApp, getApps, getApp, type FirebaseApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyC8zgOh2u-s54p8_UlAtEtdpej-b-etznM',
  authDomain: 'agencyos-synth.firebaseapp.com',
  projectId: 'agencyos-synth',
  storageBucket: 'agencyos-synth.firebasestorage.app',
  messagingSenderId: '55061471600',
  appId: '1:55061471600:web:faf49f550259ce5ec6afb5',
};

// Evita erro de "App already exists" em hot-reload
const app: FirebaseApp = getApps().length
  ? getApp()
  : initializeApp(firebaseConfig);

export const auth: Auth = getAuth(app);
export const provider = new GoogleAuthProvider();
export const db: Firestore = getFirestore(app);
