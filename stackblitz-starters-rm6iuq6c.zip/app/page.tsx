import AgencyMindMap from '../components/AgencyMindMap';
export default function Page() {
  return <AgencyMindMap />;
}
